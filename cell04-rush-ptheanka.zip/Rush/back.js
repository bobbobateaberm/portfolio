
document.body.addEventListener("click", function(event) {
    // Check if the clicked element is a button with the specific ID
    if (event.target.id === "but1") {
        window.location.href = "p1.html"; // Handle the first button click
    } else if (event.target.id === "but2") {
        window.location.href = "p2.html"; // Handle the second button click

    }
    // You can add more conditions for other buttons as needed
});
document.getElementById("bututube").addEventListener("click", function() {
    // Specify the URL you want to open in a new tab
    var url = "https://www.youtube.com/@phunipith1383"; // Replace with your desired URL

    // Use window.open() to open the URL in a new tab
    window.open(url, "_blank");
});

